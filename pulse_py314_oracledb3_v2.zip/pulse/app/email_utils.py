import smtplib
from email.mime.text import MIMEText
from email.utils import formataddr
from flask import current_app

def send_email(to_email: str, subject: str, html_body: str):
    cfg = current_app.config
    msg = MIMEText(html_body, 'html')
    msg['Subject'] = subject
    msg['From'] = formataddr(('Pulse', cfg['DEFAULT_FROM_EMAIL']))
    msg['To'] = to_email
    with smtplib.SMTP(cfg['SMTP_SERVER'], cfg['SMTP_PORT']) as s:
        if cfg.get('SMTP_USE_TLS'):
            s.starttls()
        if cfg.get('SMTP_USERNAME'):
            s.login(cfg['SMTP_USERNAME'], cfg['SMTP_PASSWORD'])
        s.sendmail(msg['From'], [to_email], msg.as_string())
