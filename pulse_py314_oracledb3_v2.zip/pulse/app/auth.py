from flask import Blueprint, render_template, request, redirect, url_for, session, flash
from . import db
from .security import verify_password, hash_password
from .email_utils import send_email
import secrets

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/login', methods=['GET','POST'])
def login():
    if request.method == 'POST':
        login_id = request.form['login_id'].strip()
        password = request.form['password']
        row = db.query_one("""
            SELECT user_id, login_id, full_name, email, role, password_hash, active
            FROM users WHERE login_id = :login_id
        """, {'login_id': login_id})
        if row and row[-2] == 1:  # active=1
            user_id, lg, full, email, role, pwd_hash, active = row
            if verify_password(password, pwd_hash):
                session['user_id'] = user_id
                session['login_id'] = lg
                session['full_name'] = full
                session['role'] = role
                flash(f'Welcome, {full}!', 'success')
                return redirect(url_for('oracle.list_targets'))
        flash('Invalid credentials or account inactive.', 'danger')
    return render_template('login.html')

@auth_bp.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('auth.login'))

@auth_bp.route('/forgot', methods=['GET','POST'])
def forgot():
    if request.method == 'POST':
        login_id = request.form['login_id'].strip()
        row = db.query_one("SELECT user_id, email FROM users WHERE login_id=:login_id", {'login_id': login_id})
        if row:
            uid, email = row
            temp_pw = secrets.token_urlsafe(10)
            db.exec_sql("UPDATE users SET password_hash=:ph WHERE user_id=:uid", {'ph': hash_password(temp_pw), 'uid': uid})
            send_email(email, 'Pulse temporary password',
                       f"""<p>Hello,</p><p>Your temporary password is: <b>{temp_pw}</b></p><p>Please log in and change it.</p>""")
        return render_template('forgot.html', sent=True)
    return render_template('forgot.html', sent=False)
