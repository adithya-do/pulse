import sys, base64
from werkzeug.security import generate_password_hash, check_password_hash
if sys.platform != 'win32':
    raise RuntimeError('DPAPI-based encryption requires Windows (IIS environment).')

import ctypes
from ctypes import wintypes
CRYPTPROTECT_UI_FORBIDDEN = 0x01

class DATA_BLOB(ctypes.Structure):
    _fields_ = [('cbData', wintypes.DWORD),
                ('pbData', ctypes.POINTER(ctypes.c_char))]

def _blob_from_bytes(b: bytes) -> DATA_BLOB:
    buf = ctypes.create_string_buffer(b)
    return DATA_BLOB(len(b), ctypes.cast(buf, ctypes.POINTER(ctypes.c_char)))

def _bytes_from_blob(blob: DATA_BLOB) -> bytes:
    return ctypes.string_at(ctypes.cast(blob.pbData, ctypes.c_void_p).value, int(blob.cbData))

CryptProtectData = ctypes.windll.crypt32.CryptProtectData
CryptProtectData.argtypes = [ctypes.POINTER(DATA_BLOB),
                             wintypes.LPCWSTR,
                             ctypes.POINTER(DATA_BLOB),
                             ctypes.c_void_p,
                             ctypes.c_void_p,
                             wintypes.DWORD,
                             ctypes.POINTER(DATA_BLOB)]
CryptProtectData.restype = wintypes.BOOL

CryptUnprotectData = ctypes.windll.crypt32.CryptUnprotectData
CryptUnprotectData.argtypes = [ctypes.POINTER(DATA_BLOB),
                               ctypes.POINTER(wintypes.LPWSTR),
                               ctypes.POINTER(DATA_BLOB),
                               ctypes.c_void_p,
                               ctypes.c_void_p,
                               wintypes.DWORD,
                               ctypes.POINTER(DATA_BLOB)]
CryptUnprotectData.restype = wintypes.BOOL

LocalFree = ctypes.windll.kernel32.LocalFree

def init_crypto():
    return True

def hash_password(raw_password: str) -> str:
    return generate_password_hash(raw_password)

def verify_password(raw_password: str, password_hash: str) -> bool:
    return check_password_hash(password_hash, raw_password)

def enc(plaintext: str) -> str:
    data_in = _blob_from_bytes(plaintext.encode('utf-8'))
    data_out = DATA_BLOB()
    if not CryptProtectData(ctypes.byref(data_in), None, None, None, None,
                            CRYPTPROTECT_UI_FORBIDDEN, ctypes.byref(data_out)):
        raise OSError('CryptProtectData failed')
    try:
        raw = _bytes_from_blob(data_out)
        return base64.b64encode(raw).decode('ascii')
    finally:
        LocalFree(data_out.pbData)

def dec(encoded: str) -> str:
    raw = base64.b64decode(encoded)
    data_in = _blob_from_bytes(raw)
    pszDesc = wintypes.LPWSTR()
    data_out = DATA_BLOB()
    if not CryptUnprotectData(ctypes.byref(data_in), ctypes.byref(pszDesc), None,
                              None, None, CRYPTPROTECT_UI_FORBIDDEN, ctypes.byref(data_out)):
        raise OSError('CryptUnprotectData failed')
    try:
        plain = _bytes_from_blob(data_out)
        return plain.decode('utf-8')
    finally:
        LocalFree(data_out.pbData)
