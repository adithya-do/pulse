# Pulse (Python 3.14 + oracledb 3.x) IIS Deployment

1) Install packages (system Python):
   ```powershell
   py -3 -m pip install --upgrade pip
   py -3 -m pip install Flask "oracledb>=3,<4" APScheduler wfastcgi
   ```

2) IIS: create App Pool (No Managed Code, 64-bit, Load User Profile=True) & Site pointing to this folder.

3) Edit `web.config`: set actual paths to `python.exe` and `wfastcgi.py`, keep `WSGI_HANDLER=app.app:application`, `PYTHONPATH` to this folder.

4) Oracle backend: run `db_init.sql`, then insert an admin with PBKDF2 hash (see below).

5) Recycle the App Pool and browse the site.

### Create initial admin (PBKDF2)
```powershell
py -3 - <<'PY'
from werkzeug.security import generate_password_hash
print(generate_password_hash("Admin@123"))
PY
```
Insert into Oracle:
```sql
INSERT INTO users(user_id, login_id, full_name, email, role, password_hash, active)
VALUES (users_seq.nextval, 'admin', 'Administrator', 'admin@example.com', 'ADMIN', '<PASTE_HASH>', 1);
COMMIT;
```
