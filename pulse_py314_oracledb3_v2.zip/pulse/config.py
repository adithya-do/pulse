import os
SECRET_KEY = os.environ.get("APP_SECRET_KEY", "3JQ8g1NCE_QNKLjPGRNnWT4WQIMJv1rcX3QvnI3HAsI")
ORACLE_APP_USER = os.environ.get("APP_DB_USER", "APP_USER")
ORACLE_APP_PASSWORD = os.environ.get("APP_DB_PASSWORD", "CHANGE_ME")
ORACLE_APP_DSN = os.environ.get("APP_DB_DSN", "localhost:1521/XEPDB1")
ORACLE_APP_MODE = os.environ.get("APP_DB_MODE", "thin")  # 'thin' or 'thick'

SMTP_SERVER = os.environ.get("SMTP_SERVER", "localhost")
SMTP_PORT = int(os.environ.get("SMTP_PORT", "25"))
SMTP_USE_TLS = bool(int(os.environ.get("SMTP_USE_TLS", "0")))
SMTP_USERNAME = os.environ.get("SMTP_USERNAME", "")
SMTP_PASSWORD = os.environ.get("SMTP_PASSWORD", "")
DEFAULT_FROM_EMAIL = os.environ.get("DEFAULT_FROM_EMAIL", "no-reply@pulse.local")

SQLCMD_PATH = os.environ.get("SQLCMD_PATH", "sqlcmd")
