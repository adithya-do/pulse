import smtplib
from email.mime.text import MIMEText
from email.utils import formataddr
from flask import current_app

def send_email(to_email, subject, html_body):
    c=current_app.config
    msg=MIMEText(html_body,'html'); msg['Subject']=subject; msg['From']=formataddr(('Pulse', c['DEFAULT_FROM_EMAIL'])); msg['To']=to_email
    with smtplib.SMTP(c['SMTP_SERVER'], c['SMTP_PORT']) as s:
        s.sendmail(msg['From'], [to_email], msg.as_string())
