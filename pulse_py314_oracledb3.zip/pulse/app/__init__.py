from flask import Flask
from . import db
from .security import init_crypto

def create_app():
    app=Flask(__name__); app.config.from_object('config'); init_crypto(); db.init_app(app)
    from .auth import auth_bp; from .admin import admin_bp; from .oracle_module import oracle_bp; from .sqlserver_module import sqlserver_bp
    app.register_blueprint(auth_bp); app.register_blueprint(admin_bp, url_prefix='/admin'); app.register_blueprint(oracle_bp, url_prefix='/oracle'); app.register_blueprint(sqlserver_bp, url_prefix='/sqlserver')
    @app.route('/')
    def index():
        from flask import redirect,url_for,session
        return redirect(url_for('auth.login')) if not session.get('user_id') else redirect(url_for('oracle.list_targets'))
    return app
