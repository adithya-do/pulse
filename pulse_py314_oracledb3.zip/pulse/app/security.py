import sys, base64
from werkzeug.security import generate_password_hash, check_password_hash
if sys.platform!='win32':
    raise RuntimeError('DPAPI requires Windows')
import ctypes
from ctypes import wintypes
CRYPTPROTECT_UI_FORBIDDEN=1
class DATA_BLOB(ctypes.Structure):
    _fields_=[('cbData',wintypes.DWORD),('pbData',ctypes.POINTER(ctypes.c_char))]

def _blob_from_bytes(b):
    buf=ctypes.create_string_buffer(b)
    return DATA_BLOB(len(b), ctypes.cast(buf, ctypes.POINTER(ctypes.c_char)))

def _bytes_from_blob(blob):
    return ctypes.string_at(ctypes.cast(blob.pbData, ctypes.c_void_p).value, int(blob.cbData))
CP=ctypes.windll.crypt32.CryptProtectData; CP.argtypes=[ctypes.POINTER(DATA_BLOB),wintypes.LPCWSTR,ctypes.POINTER(DATA_BLOB),ctypes.c_void_p,ctypes.c_void_p,wintypes.DWORD,ctypes.POINTER(DATA_BLOB)]; CP.restype=wintypes.BOOL
CU=ctypes.windll.crypt32.CryptUnprotectData; CU.argtypes=[ctypes.POINTER(DATA_BLOB),ctypes.POINTER(wintypes.LPWSTR),ctypes.POINTER(DATA_BLOB),ctypes.c_void_p,ctypes.c_void_p,wintypes.DWORD,ctypes.POINTER(DATA_BLOB)]; CU.restype=wintypes.BOOL
LF=ctypes.windll.kernel32.LocalFree

def init_crypto():
    return True

def hash_password(p):
    return generate_password_hash(p)

def verify_password(p,h):
    return check_password_hash(h,p)

def enc(s:str)->str:
    din=_blob_from_bytes(s.encode()); dout=DATA_BLOB()
    if not CP(ctypes.byref(din), None, None, None, None, CRYPTPROTECT_UI_FORBIDDEN, ctypes.byref(dout)):
        raise OSError('CryptProtectData failed')
    try:
        raw=_bytes_from_blob(dout)
        return base64.b64encode(raw).decode('ascii')
    finally:
        LF(dout.pbData)

def dec(encs:str)->str:
    raw=base64.b64decode(encs); din=_blob_from_bytes(raw); psz=wintypes.LPWSTR(); dout=DATA_BLOB()
    if not CU(ctypes.byref(din), ctypes.byref(psz), None, None, None, CRYPTPROTECT_UI_FORBIDDEN, ctypes.byref(dout)):
        raise OSError('CryptUnprotectData failed')
    try:
        return _bytes_from_blob(dout).decode()
    finally:
        LF(dout.pbData)
