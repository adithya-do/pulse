import oracledb
from flask import current_app,g
import threading
_pool_lock=threading.Lock()

def _get_pool():
    if 'db_pool' not in g:
        c=current_app.config
        with _pool_lock:
            g.db_pool=oracledb.create_pool(user=c['ORACLE_APP_USER'], password=c['ORACLE_APP_PASSWORD'], dsn=c['ORACLE_APP_DSN'], min=1, max=5, increment=1)
    return g.db_pool

def get_conn():
    return _get_pool().acquire()

def close_pool(e=None):
    p=g.pop('db_pool',None)
    p and p.close()

def init_app(app):
    app.teardown_appcontext(close_pool)

def query_one(sql,params=None):
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(sql, params or {})
            return cur.fetchone()

def query_all(sql,params=None):
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(sql, params or {})
            cols=[d[0] for d in cur.description]
            return [dict(zip(cols,r)) for r in cur.fetchall()]

def exec_sql(sql,params=None,commit=True):
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(sql, params or {})
        if commit:
            conn.commit()
